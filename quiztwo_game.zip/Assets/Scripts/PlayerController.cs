using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody playerRb;
    private GameObject focalPoint;
    public float speed = 5.0f;
    
    public GunsPower currentGunPower = GunsPower.First;
    public GameObject bulletsPrefab;
    public GameObject bullets2Prefab;
    public GameObject bullets3Prefab;
    private GameObject FireBullet;
    
    public float hangTime;
    public float smashSpeed;
    public float explosionForce;
    public float explosionRadius;
    bool smashing = false;
    float floorY;
    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody>();
        focalPoint = GameObject.Find("FocalPoint");
    }

    // Update is called once per frame
    void Update()
    {
        GunChanger();
        float forwardInput = Input.GetAxis("Vertical");
        playerRb.AddForce(focalPoint.transform.forward * forwardInput * speed);
        if (currentGunPower == GunsPower.Third && Input.GetKeyDown(KeyCode.F))
        {
            LaunchBullets();
        }
        if (currentGunPower == GunsPower.fourth && Input.GetKeyDown(KeyCode.F))
        {
            LaunchSecondBullets();
        }
        if (currentGunPower == GunsPower.fifth && Input.GetKeyDown(KeyCode.F))
        {
            LaunchThirdBullets();
        }
        if (currentGunPower == GunsPower.second && Input.GetKeyDown(KeyCode.Space) && !smashing)
        {
            smashing = true;
            StartCoroutine(Smash());
        }


    }
    

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy") && currentGunPower == GunsPower.First)
        {
            Rigidbody enemyRigidbody = collision.gameObject.GetComponent<Rigidbody>();
            Vector3 awayFromPlayer = (collision.gameObject.transform.position - transform.position);

            Debug.Log("Player collided with: " + collision.gameObject.name + " with powerup set to " + currentGunPower.ToString());

            enemyRigidbody.AddForce(awayFromPlayer * 50, ForceMode.Impulse);
        }
    }

    void LaunchBullets()
    {
        foreach (var enemy in FindObjectsOfType<Enemy>())
        {
            FireBullet = Instantiate(bulletsPrefab, transform.position + Vector3.up, Quaternion.identity);
            FireBullet.GetComponent<BulletBehaviour>().Fire(enemy.transform);
        }
    }
    void LaunchSecondBullets()
    {
        foreach (var enemy in FindObjectsOfType<Enemy>())
        {
            FireBullet = Instantiate(bullets2Prefab, transform.position + Vector3.up, Quaternion.identity);
            FireBullet.GetComponent<BulletBehaviour>().Fire(enemy.transform);
        }
    }
    void LaunchThirdBullets()
    {
        foreach (var enemy in FindObjectsOfType<Enemy>())
        {
            FireBullet = Instantiate(bullets3Prefab, transform.position + Vector3.up, Quaternion.identity);
            FireBullet.GetComponent<BulletBehaviour>().Fire(enemy.transform);
        }
    }
    IEnumerator Smash()
    {
        var enemies = FindObjectsOfType<Enemy>();
        floorY = transform.position.y;
        float jumpTime = Time.time + hangTime;
        while (Time.time < jumpTime)
        {
            playerRb.velocity = new Vector2(playerRb.velocity.x, smashSpeed);
            yield return null;
        }
        while (transform.position.y > floorY)
        {
            playerRb.velocity = new Vector2(playerRb.velocity.x, -smashSpeed * 2);
            yield return null;
        }
        for (int i = 0; i < enemies.Length; i++)
        {
            if (enemies[i] != null)
                enemies[i].GetComponent<Rigidbody>().AddExplosionForce(explosionForce, transform.position, explosionRadius, 5.0f, ForceMode.Impulse);
        }
        smashing = false;
    }
    
    void GunChanger()
    {
        if (Input.GetKeyDown("1"))
        {
            currentGunPower = GunsPower.First;
        }
        else if (Input.GetKeyDown("2"))
        {
            currentGunPower = GunsPower.second;
        }
        else if (Input.GetKeyDown("3"))
        {
            currentGunPower = GunsPower.Third;
        }
        else if (Input.GetKeyDown("4"))
        {
            currentGunPower = GunsPower.fourth;
        }
        else if (Input.GetKeyDown("5"))
        {
            currentGunPower = GunsPower.fifth;
        }
    }


}
